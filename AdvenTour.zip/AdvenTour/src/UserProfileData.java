/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Dell
 */
public class UserProfileData {
    private static String userName;
    
    public static String getUserName() {
        return userName;
    }
    
    public static void setUserName(String userName) {
      UserProfileData.userName = userName;
    }
 
}
